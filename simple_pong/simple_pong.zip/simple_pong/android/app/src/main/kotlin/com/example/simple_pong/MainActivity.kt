package com.example.simple_pong

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
